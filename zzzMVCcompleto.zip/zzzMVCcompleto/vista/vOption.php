<!DOCTYPE html>
<html lang="es">
	<head>
		<title>Marco Domínguez</title>
		<meta charset="UTF-8">
        <meta name="author" content="Marco Dominguez">
        <meta name="description" content="MVC1">
        <link rel="stylesheet" href="estilo.css">
	</head>
	<body>
        <div>
            <form action="./controlador/cOption.php" method="get">
            <br><strong>Elija una opción: </strong><br><br>
                <input type="submit" name="formulario" value="Añadir">-
                <input type="submit" name="formulario" value="Ver">-
                <input type="submit" name="formulario" value="Modificar">-
                <input type="submit" name="formulario" value="Eliminar"><br>
                un usuario
            </form>
        </div>
</body>
</html>