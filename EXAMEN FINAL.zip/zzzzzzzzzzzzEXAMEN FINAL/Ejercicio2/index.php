<?php
    require_once("./fichero.php");
?>