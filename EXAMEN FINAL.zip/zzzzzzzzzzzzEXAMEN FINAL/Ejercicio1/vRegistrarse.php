<!DOCTYPE html>
<html lang="es">
<head>
    <title>Marco Domínguez</title>
    <meta charset="UTF-8">
    <meta name="author"      content="Marco Dominguez">
    <meta name="description" content="Examen final">
    <link rel="stylesheet" href="./estilo.css">
</head>
<body>
   
    <form action="./cRegistrarse.php" method="post">
        Clave de registro<br>
        <label for="intclave">Clave</label> 
            <input type="password" name="clave" id="intclave" value=""><br><br>

        <input type="submit" name="formulario" value="Alta"><br><br>
    </form>

</body>
</html>