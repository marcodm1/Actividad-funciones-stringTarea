<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cerrar</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="registro">
        <form class="volverJugar" action="registro.php" method="POST">
            <p>Gracias por participar</p>
        <input type="submit" value="Pulsa para volver a jugar">
    </div>
</body>
</html>