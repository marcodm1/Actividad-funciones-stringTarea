<?php  
     require_once("./principal.php");
?> 